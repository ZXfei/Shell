#!/bin/bash
nginx="/usr/local/nginx/sbin/nginx" 
ls $nginx &> /dev/null
if [ $? -ne 0 ];then
	echo "你还未安装nginx。" 
	exit
fi
start=$nginx
stop="$nginx -s stop"
status="$nginx -V"
case $1 in
start)
	$stop
	$start
	echo "成功启动。";;
stop)
	$stop
	echo "成功关闭。";;
restart)
	$stop
	$start
	echo "重起服务成功。";;
status)
	$nginx -V
	netstat -ntulp | grep -q nginx
	if [ $? -eq 0 ];then
		echo 服务已启动
	else
		echo 服务未启动
	fi;;
*)
	echo "未发现服务"
	exit
esac
	
