#!/bin/bash
#一键部署Nginx安装脚本
echo "正在检测yum源..."
N=`yum repolist | awk '/repolist:/{print $2}' | sed s/,//`
if [ $N -eq 0 ];then
	echo "检测完成，yum源不完整。"
	exit
else 
	echo "检测完成，yum源完整。"
fi

echo "即将部署Nginx软件..."
echo "正在检测Nginx软件包..."
D=`find / -name "nginx-1.13.12.tar.gz" -type f`
if [ $? -eq 0 ];then
	echo "检测完成，存在tar包。"
	echo "该tar包存放在 $D 路径下。"
else 
	echo "检测完成，不存在tar包。"
	exit
fi
echo "一键部署Nginx及相关rpm包"
yum -y install gcc openssl-devel pcre-devel
tar -xf $D 
d=${D%.*}
d=${d%.*}
d=${d##*/}
cd $d
./configure
make
make install
echo "安装完成。"
echo "确认安装效果..."
echo "	启动nginx服务..."
/usr/local/nginx/sbin/nginx
echo "成功启动。"
echo "关闭nginx服务..."
/usr/local/nginx/sbin/nginx -s stop
echo "成功关闭。"
echo "查看软件信息..."
/usr/local/nginx/sbin/nginx -V

