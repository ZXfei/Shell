#!/bin/bash
cat /var/log/secure | awk '/Failed password/' | awk '{print $11}' | awk '{ip[$1]++}
END{for(i in ip){
if(ip[i] < 3 && ip[i]>0){print "IP"i"正常连接"}
if(ip[i] >= 3){print i"连接次数超过3次，将拒绝"i"再次连接"}
else{print "没有IP连接该主机"}
}}'
#下面这种方法只能判断一个IP
#echo $ip
#if [ -z $ip ];then
#	echo "未找到远程的IP"
#fi
#for i in $ip
#do
#	num=${i#* }
#if [ $num -lt 3  ];then
#	echo "连接正常"
#else 
#	echo "连接次数超过3次，将拒绝该$ip再次连接"
#fi
#done
