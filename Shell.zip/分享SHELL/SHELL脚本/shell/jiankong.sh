#!/bin/bash
echo ':'
uptime | awk '{print "CPU的负载是："$10}'
ifconfig private1 | awk '/inet/{print "本机的IP为："$2}'
ifconfig private1 | awk '/RX p/{print "接受的数据流量："$3"KB"}'
ifconfig private1 | awk '/TX p/{print "发送的数据流量："$3"KB"}'
free | awk '/Mem/{print "内存剩余:"$7"KB"}'
df | awk '/\/$/{print "磁盘剩余容量："$4"KB"}'
awk '{nu++}END{print "计算机账户的数量为："nu}' /etc/passwd
who | awk '{num++}END{print "当前登录账户的数量为："num}'
ps aux | awk '{ps++}END{print "计算机当前开启的进程数量为:"ps}'
rpm -qa | awk '{rpm++}END{print "本机已安装的软件包数量:"rpm}'

