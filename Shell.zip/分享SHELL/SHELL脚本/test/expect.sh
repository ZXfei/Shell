#!/bin/bash
expect << EOF
spawn ssh 192.168.4.1
expect "password:" {send "1\r"}
expect "#" {send "pwd\r"}
expect "#" {send "exit\r"}
EOF
